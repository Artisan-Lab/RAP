//
// Created by VaynNecol on 2021/9/27.
//

#ifndef RAP_PHASE_LLVM_TEST_H
#define RAP_PHASE_LLVM_TEST_H

void test_parsing(llvm::Module &m);

#endif //RAP_PHASE_LLVM_TEST_H